# HCCRO — Stages 2–5 Implementation

This delivers exactly the three items you asked for, structured to drop
straight into `hccro_resilience_project/` alongside your existing
`stage1_csa.py`:

```
src/
  stages/
    stage2_ctig.py   -> CognitiveThreatGraph (Task: Build the NetworkX Graph)
    stage3_aim.py    -> PredictiveModelRegistry + AttackIntentionModeler (Task 1)
    stage4_aep.py    -> AttackEvolutionPredictor, Independent Cascade Model (Task 2, first half)
    stage5_mia.py    -> MissionImpactEstimator (Task 2, second half)
  utils/
    state_vector.py     -> StateVector / SituationVector (swap for your Stage 1's if named differently)
    train_classifier.py -> trains + saves the Stage 3 ML classifier (Task 1's "Train")
  core/
    demo_stage2_to_5.py -> end-to-end sanity check, runs all four stages over 4 scenarios
```

## 1. `stage2_ctig.py` — CognitiveThreatGraph

- `add_satellite(sat_id, neighbors=...)` builds each satellite plus its two
  onboard service nodes (`SAT-N::TRANSCEIVER`, `SAT-N::ROUTING_SW`) and wires
  `DEPENDS_ON` edges.
- `link_satellites(a, b, trust=...)` adds the P2P `COMMUNICATES_WITH` edges
  (with a `trust` weight Stage 4 reuses as the inverse propagation
  probability).
- `ingest(sat_id, situation, state)` applies the three anomaly thresholds
  straight from spec §4.1/§4.2 (C/N0 < 25 dB-Hz -> JAMMING, GPS drift >
  15 m -> SPOOFING, CPU/RAM > 90% -> DoS) and, on a hit, injects a
  `THREAT_INDICATOR` node with directed `EXPLOITS` edges into the targeted
  service node(s) and a `TARGETS` edge into the satellite itself.

## 2. `stage3_aim.py` + `train_classifier.py` — ML threat classification

- `PredictiveModelRegistry` is the decoupling layer the spec calls for:
  register any scikit-learn-compatible model under a name, swap the
  "active" one at runtime, and `AttackIntentionModeler` will use it via
  `.predict()` / `.predict_proba()` automatically.
- `train_classifier.py` trains a RandomForest (default; SVM and MLP are one
  flag away: `--model svm|mlp`) on an 11-feature vector that mirrors the
  fused Mendeley-GNSS + OPS-SAT-AD columns (C/N0, GPS drift, DOP, CPU/RAM,
  battery, delay, PDR, trust, plus the live `E`/`T` state-vector
  components).
- **Data note:** it ships with a synthetic generator so the pipeline runs
  today. Swap `make_synthetic_dataset()` for a real loader over your two
  downloaded CSVs — the column mapping is already spelled out in spec
  §4.1/§4.2 and in the function's docstring — and everything downstream is
  unaffected.
- `AttackIntentionModeler.infer(...)` always tries the registered model
  first, and only falls back to the deterministic
  JAMMING→RF_JAMMING_DISRUPTION / SPOOFING→COMMAND_SPOOFING_TAKEOVER /
  DoS→RESOURCE_DENIAL_OF_SERVICE heuristic if no model is active or it
  throws.

## 3. `stage4_aep.py` + `stage5_mia.py` — propagation + mission impact

- `AttackEvolutionPredictor.predict(ctig, horizon_ticks=3)` seeds a Monte
  Carlo Independent Cascade Model from every satellite currently hosting a
  `THREAT_INDICATOR`, and propagates along `COMMUNICATES_WITH` edges with
  `p(u→v) = severity_u * (1 - trust(u,v)) * 0.6`. Running an ensemble
  (default 500 trials) turns the single-run ICM into a per-tick, per-
  satellite *probability* of compromise, which is what Stage 5 needs.
- `MissionImpactEstimator.assess(forecast, states)` turns that probability
  into expected PDR drop and bandwidth drop per satellite, the
  constellation-wide Mission Degradation Index (MDI — a mission-performance-
  weighted average compromise probability), and a risk-adjusted `omega*`
  per satellite using the kappa=1.2 recovery multiplier from spec §2.4 —
  ready to plug straight into Stage 6's DREI numerator.

## Running the demo

```bash
cd hccro_resilience_project
python -m src.utils.train_classifier --model rf     # trains + saves models/threat_classifier_rf.joblib
python -m src.core.demo_stage2_to_5                 # nominal / jamming / spoofing / DoS walkthrough
```

## Notes / things you'll likely want to tune

- `CN0_JAMMING_THRESHOLD_DB_HZ`, `GPS_DRIFT_SPOOFING_THRESHOLD_M`,
  `CPU_DOS_THRESHOLD_PCT` in `stage2_ctig.py` are the exact spec thresholds
  — adjust once you've looked at the real dataset distributions.
- `ICM_SCALE` in `stage4_aep.py` controls how aggressively attacks spread;
  tune it against the real inter-satellite link topology once available.
- The synthetic classifier training data is a placeholder — real Mendeley +
  OPS-SAT labels will materially change classifier accuracy and the
  intent/feature relationships it learns.
